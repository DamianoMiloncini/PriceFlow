# Assignment01_eCommerce
Assignment 01 of Michaella Nsumanyi and Damiano Miloncini

# What is needed to start application (start up checklist)
-Create the .htaccess file and copy the code we did in class
-Create the app folder
-add the core folder inside the app folder
-create the init.php file
-Create the App.php file which will hold all the framework
-Create the autoload.php which will allow us to have dynamic loading
-Add the required files in the init.php (don't close the php enclosion !)
-Require the init.php file in the index.php file so that it is served as an entry point
-Start build the App.php file (namespace,create the class,constructor,...)

# TODO tomorrow (Feb.16 2024)
create the routes (half of them)
compare the routes to resolve the route
create the view folder
add view files (half of them)

# WHAT IS LEFT TO DO FOR THE ASSIGNMENT
-Make the Contact/index.php
-Make the Contact/read.php
-Add them to the routes
-Create the methods in the Controller
-Make the models/Message.php
-If everything is done in time, let's do the bonus part 
-Double check that everything is good ! 



