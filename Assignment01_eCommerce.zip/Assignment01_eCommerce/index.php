<?php
//index php is used as an entry point so you need to require the init file.
use app\core\App;

require('app/core/init.php');

//Instantiate the App class
new App();