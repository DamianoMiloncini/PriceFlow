<?php
namespace app\models;

class message {
    public $message;
    public $email;
    //public $IP;

    public function __construct($object = null)
    {
        //if the object has no parameter, no need to execute the rest.
        if ($object == null) {
            return;
        }
        $this->message = $object->message;
        $this->email = $object->email;
        //$this->IP = $object->IP;
    }

    public function read() {
        $filename = 'resources/messages.txt';
        $results = file($filename);
        // We must decode each line of the text file since tehyre in JSON format (as we encoded in the write)
        //return json_decode($results, true); // The true means itll return an associative array 
        $data = [];

        foreach ($results as $key => $value){
            $object = json_decode($value, true);
            $model = new \app\models\Model($object);
            $data[$key] = $model;
        }
        return $data;

    }

    public function write() {
        $filename = 'resources/messages.txt';

        // When writing to the file, we want to append to add data to the file (using a). This is why we call it a file handler
        $fileHandler = fopen($filename, 'a'); // We are using double quotes because we want to use the absolute string

        // Locking the file to ensure no modified version interes with the current one
        flock($fileHandler, LOCK_EX); // We are using EX (exclusive lock) as it is the correct lock for writing to files.


        // Converting to a JSON object using json_encode
        $message = json_encode($this);

        // Now we will write the file by concatenating the new contents and creating a new line
        fwrite($fileHandler, $message . "\n");

        // Unlocking the fileHandler
        flock($fileHandler, LOCK_UN);

        // Finally, we will close the file handler. This is good practice
        fclose($fileHandler);

    }
}