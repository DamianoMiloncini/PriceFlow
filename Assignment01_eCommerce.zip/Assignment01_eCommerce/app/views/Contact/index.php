<html>

    <head>

        <title>Index page</title>
        <!-- Add bootstrap CSS and JS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

        <style>

            #message{
                resize: none;
            }

            #sidebar{
                margin-right: auto;
            }

        </style>

    </head>

    <body>

        <!-- Site landing page view -->
        <h1>Contact Us</h1>

        <table>
            <tr>
                <td style="width:250px; vertical-align: top;">
                    <section id = 'sidebar'>
                        <ul>
                            <li><a href="/Main/index">Landing Page</a></li>
                            <li><a href="/Main/about_us">About us</a></li>
                            <li><a href="/Contact/index">Contact us</a></li>
                            <li><a href="/Contact/read">See the message we get</a></li>
                        </ul>
                    </section>
                </td>
            

            
                <td style="vertical-align: top;">

                    <h1>Contact Us!</h1>
                    <p>Want to reach us? Please fill in the following information and then submit.</p>

                    <form method="post" action='\contact\messageForm'>
                        <table>
                            <tr>
                                <td>
                                <label for="email" style="width:150px">Email:</label>
                                </td>
                                <td>
                                    <input type="email" id="email" name="email" style="width:350px">
                                </td>
                            </tr>

                            <tr>        
                                <td>
                                    <label for = "message">Message:</label>
                                </td>
                                <td>
                                    <textarea id="message" name="message" style="width:100%"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td></td>
                                <td >
                                    <input type="submit" value="Send!" style="width:100%">
                                </td>
                            </tr>

                        </table>
                    </form>

                </td>
            </tr>

        </table>


        

    </body>

</html>