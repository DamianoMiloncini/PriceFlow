<?php
namespace app\controllers;

class Contact extends \app\core\Controller {

    function index() {
    $this->view('Main/index');
    }

    function about_us() {
        $this->view('Main/about_us');
    }

    function messageForm(){
        echo"hello";
        // Creating an object for the model
        $model = new \app\models\Model();
        // Populate the properties
        $model->email = $_POST['email'];
        $model->message = $_POST['message'];
        // Calling the write method from the model
        $model->write();

        $this->view('Main/about_us');

        header("location:/Contact/index"); 

    }

    function displayData(){
        $model = new \app\models\Model();

        $data = $model->read();

        // Passing data to the view
        $this->view('Contact/read', ['data'=>$data]);
    }

    function formPage(){
        $this->view('Contact/index');
    }

    // function readMessage() {
    //     $this->view('Contact/read');
    // }

}

