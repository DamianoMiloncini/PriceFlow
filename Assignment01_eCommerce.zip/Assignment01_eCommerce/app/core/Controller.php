<?php
namespace app\core;

class Controller {
    function view ($name, $data=null) {
    //load files to present them to the browser
    include('app/views/' . $name . '.php');
    }
}


