<?php
namespace app\core;

class App {

    function __construct()
    {
        //* The URL is ALWAYS an Array
        $url = $_GET['url'];

        //create the routes
        $routes =
        [
            'Main/index'=>'Contact,index',
            'Main/about_us'=>'Contact,about_us',
            'Contact/index'=>'Contact,formPage',
            'Contact/read'=>'Contact,displayData',
            'contact/messageForm'=>'Contact,messageForm'
        ];
        //compare the routes to resolve the route
        foreach ($routes as $routeUrl => $controllerMethod) {
            if($url == $routeUrl){//match the route
                //run the route
                [$controller,$method]=explode(',', $controllerMethod);
                $controller = '\\app\\controllers\\'.$controller;
                $controller = new $controller();
                $controller->$method();
                //make sure that we don't run a second route
                break;
            }
        }
    }
}

