<?php
require('app/core/App.php');
require('app/core/Controller.php');
//require('app/models/message.php');
require('app/core/autoload.php');