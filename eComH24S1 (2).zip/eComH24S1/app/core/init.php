<?php
session_start();
require('app/core/App.php');
require('app/core/Controller.php');
require('app/core/autoload.php');
//future inclusion for Model
